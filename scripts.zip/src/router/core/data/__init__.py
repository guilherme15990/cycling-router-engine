"""L1 - dados e grafo: ingestao OSM/PBF, grafo, elevacao, snapping, geo."""
